//
//  UIScrollView+NoData.m
//
//  Created by Barney on 2017/2/6.
//

#import "UIScrollView+NoData.h"
#import <objc/runtime.h>

@implementation UIScrollView (NoData)

#pragma mark - zh_holder
static const char ZHholderKey = '\0';

#pragma mark - Getters % Setters
- (void)setZh_holder:(ZHPlaceholder *)zh_holder {
    if (zh_holder != self.zh_holder) {
        // 删除旧的，添加新的
        [self.zh_holder removeFromSuperview];
        [self addSubview:zh_holder];
        
        // 存储新的
        [self willChangeValueForKey:@"zh_holder"]; // KVO
        objc_setAssociatedObject(self,
                                 &ZHholderKey,
                                 zh_holder,
                                 OBJC_ASSOCIATION_ASSIGN);
        [self didChangeValueForKey:@"zh_holder"]; // KVO
    }
}

- (ZHPlaceholder *)zh_holder {
    return objc_getAssociatedObject(self, &ZHholderKey);
}

@end
