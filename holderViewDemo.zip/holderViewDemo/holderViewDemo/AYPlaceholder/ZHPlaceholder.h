//
//  AYPlaceholder.h
//
//  Created by Barney on 2017/2/6.
//

#import <UIKit/UIKit.h>
#import "UIView+MJExtension.h"

typedef void (^ZHPlaceholderComponentClickBlock)();



@interface ZHPlaceholder : UIView

@property (copy, nonatomic) ZHPlaceholderComponentClickBlock clickedBlock;



//--------------------------------------------------------------------------------
//
// Description  - 单例初始化方式
// Para         - 1.height(float),当前 header 和 sectionheader 加起来的高度
//                2.pic(NSString),占位图片
//                3.clickedBlock(ZHPlaceholderComponentClickBlock),点击图片的 block 回调
// Return       - NULL
// Author       - Zhao Han
//
+ (instancetype)headerHeight:(float)height
                  andHoldPic:(NSString *)pic
      holderWithClickedBlock:(ZHPlaceholderComponentClickBlock)clickedBlock;
//--------------------------------------------------------------------------------

@end
