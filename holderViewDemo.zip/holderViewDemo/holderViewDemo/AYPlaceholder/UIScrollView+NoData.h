//
//  UIScrollView+NoData.h
//
//  Created by Barney on 2017/2/6.
//

#import <UIKit/UIKit.h>
#import "ZHPlaceholder.h"

@interface UIScrollView (NoData)

@property (nonatomic, strong) ZHPlaceholder *zh_holder;

@end
