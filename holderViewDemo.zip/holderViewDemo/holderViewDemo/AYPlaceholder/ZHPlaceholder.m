//
//  AYPlaceholder.m
//
//  Created by Barney on 2017/2/6.
//

#import "ZHPlaceholder.h"

@interface ZHPlaceholder()

@property (nonatomic, strong) UIImageView             *holdView;
@property (nonatomic, assign) float                   headerHeight;
@property (nonatomic, copy) NSString                  *picName;
@property (weak, nonatomic, readonly) UIScrollView    *scrollView;

@end



@implementation ZHPlaceholder

#pragma mark - Life Circle
+ (instancetype)headerHeight:(float)height
                  andHoldPic:(NSString *)pic
      holderWithClickedBlock:(ZHPlaceholderComponentClickBlock)clickedBlock {
    ZHPlaceholder *zhholder = [[self alloc] initWithheaderHeight:height
                                                      andHoldPic:pic
                                          holderWithClickedBlock:clickedBlock];
    return zhholder;
}

- (instancetype)initWithheaderHeight:(float)height
                          andHoldPic:(NSString *)pic
              holderWithClickedBlock:(ZHPlaceholderComponentClickBlock)clickedBlock {
    if (self = [super init]) {
        [self setHeaderHeight:height];
        [self setPicName:pic];
        [self setClickedBlock:clickedBlock];
        
        [self setBackgroundColor:[UIColor whiteColor]];
        [self addSubview:self.holdView];
        [self prepare];
    }
    
    return self;
}

#pragma mark - Self Functions
- (void)prepare {
    [self setFrame:CGRectMake(0,
                              self.headerHeight,
                              [UIScreen mainScreen].bounds.size.width,
                              self.scrollView.frame.size.height - self.headerHeight)];
    
    [self.holdView setFrame:CGRectMake(50,
                                       50,
                                       self.frame.size.width - 100,
                                       self.frame.size.width - 100)];
}

- (void)willMoveToSuperview:(UIView *)newSuperview {
    [super willMoveToSuperview:newSuperview];
    
    if (newSuperview && ![newSuperview isKindOfClass:[UIScrollView class]]) return;
    
    [self removeObservers];
    
    if (newSuperview) {
        self.mj_w = newSuperview.mj_w;
        self.mj_x = 0;
        
        _scrollView = (UIScrollView *)newSuperview;
        _scrollView.alwaysBounceVertical = YES;
        
        [self addObservers];
    }
}

#pragma mark - Control Events
- (void)holdViewClicked {
    if (self.clickedBlock) {
        self.clickedBlock();
    }
}

#pragma mark - KVO
- (void)addObservers {
    NSKeyValueObservingOptions options = NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld;
    [self.scrollView addObserver:self
                      forKeyPath:@"contentSize"
                         options:options
                         context:nil];
}

- (void)removeObservers {
    [self.superview removeObserver:self
                        forKeyPath:@"contentSize"];
}

- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
    if (!self.userInteractionEnabled) return;
    
    if ([keyPath isEqualToString:@"contentSize"]) {
        if (self.scrollView.contentSize.height > self.headerHeight) {
            self.hidden = YES;
        }else {
            self.hidden = NO;
            [self prepare];
            [self.holdView setImage:[UIImage imageNamed:self.picName]];
        }
    }
}

#pragma mark - Getters & Setters
- (UIImageView *)holdView {
    if (_holdView == nil) {
        _holdView = [[UIImageView alloc] init];
        [_holdView setContentMode:UIViewContentModeScaleAspectFit];
        [_holdView setUserInteractionEnabled:YES];
        UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                 action:@selector(holdViewClicked)];
        [_holdView addGestureRecognizer:tapGes];
    }
    
    return _holdView;
}

@end
